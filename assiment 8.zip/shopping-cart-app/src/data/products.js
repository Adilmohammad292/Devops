// Product catalog. Each product carries what ProductCard needs to render
// and what Cart needs once it's added: id, name, price, image.
const products = [
  {
    id: 1,
    name: 'Canvas Weekender Bag',
    price: 2499,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&q=80',
  },
  {
    id: 2,
    name: 'Ceramic Pour-Over Set',
    price: 1299,
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&q=80',
  },
  {
    id: 3,
    name: 'Wireless Desk Lamp',
    price: 1899,
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&q=80',
  },
  {
    id: 4,
    name: 'Merino Wool Scarf',
    price: 999,
    image: 'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?w=400&q=80',
  },
  {
    id: 5,
    name: 'Leather Notebook Cover',
    price: 749,
    image: 'https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=400&q=80',
  },
  {
    id: 6,
    name: 'Stoneware Mug Duo',
    price: 899,
    image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&q=80',
  },
]

export default products
