// Cart receives the cart items array plus three callbacks (remove, change
// quantity, clear) from App. It never mutates state itself -- App owns the
// state, Cart only asks App to change it, which is the React data-flow
// pattern the assignment calls for.
function Cart({ cartItems, onRemove, onChangeQty, onClearCart, total }) {
  return (
    <section className="cart">
      <div className="cart__heading-row">
        <h2 className="cart__heading">Your Cart</h2>
        {cartItems.length > 0 && (
          <button className="cart__clear-btn" onClick={onClearCart}>
            Clear Cart
          </button>
        )}
      </div>

      {cartItems.length === 0 ? (
        <p className="cart__empty">Cart is Empty</p>
      ) : (
        <>
          <ul className="cart__list">
            {cartItems.map((item) => (
              <li className="cart__item" key={item.id}>
                <img className="cart__item-image" src={item.image} alt={item.name} />
                <div className="cart__item-info">
                  <p className="cart__item-name">{item.name}</p>
                  <p className="cart__item-price">₹{item.price.toLocaleString('en-IN')}</p>
                </div>
                <div className="cart__item-qty">
                  <button
                    className="qty-btn"
                    onClick={() => onChangeQty(item.id, item.quantity - 1)}
                    aria-label="Decrease quantity"
                  >
                    −
                  </button>
                  <span className="qty-value">{item.quantity}</span>
                  <button
                    className="qty-btn"
                    onClick={() => onChangeQty(item.id, item.quantity + 1)}
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
                <p className="cart__item-subtotal">
                  ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                </p>
                <button
                  className="cart__remove-btn"
                  onClick={() => onRemove(item.id)}
                  aria-label={`Remove ${item.name}`}
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>

          <div className="cart__total-row">
            <span>Total</span>
            <span className="cart__total-value">₹{total.toLocaleString('en-IN')}</span>
          </div>
        </>
      )}
    </section>
  )
}

export default Cart
