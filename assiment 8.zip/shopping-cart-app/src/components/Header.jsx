// Header receives cartCount as a prop from App (the parent) and re-renders
// automatically whenever that number changes.
function Header({ appName, cartCount }) {
  return (
    <header className="header">
      <div className="header__brand">
        <span className="header__mark">🛍️</span>
        <span className="header__name">{appName}</span>
      </div>
      <div className="header__cart">
        <span className="header__cart-icon">🧺</span>
        <span className="header__cart-count">{cartCount}</span>
      </div>
    </header>
  )
}

export default Header
