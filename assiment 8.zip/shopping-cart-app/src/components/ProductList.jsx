import ProductCard from './ProductCard'

// ProductList receives the full products array and the onAddToCart
// callback from App, then passes each product down to a ProductCard via props.
function ProductList({ products, onAddToCart }) {
  return (
    <section className="product-list">
      <h2 className="product-list__heading">Our Products</h2>
      <div className="product-list__grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
        ))}
      </div>
    </section>
  )
}

export default ProductList
