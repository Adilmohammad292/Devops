import { useState } from 'react'

// ProductCard owns a tiny piece of local state -- the quantity the shopper
// wants to add -- while the product's name/price/image arrive as props
// from ProductList. This is the "bonus" +/- quantity control.
function ProductCard({ product, onAddToCart }) {
  const [quantity, setQuantity] = useState(1)

  const decrease = () => setQuantity((q) => Math.max(1, q - 1))
  const increase = () => setQuantity((q) => q + 1)

  const handleAddToCart = () => {
    onAddToCart(product, quantity)
    setQuantity(1)
  }

  return (
    <article className="product-card">
      <div className="product-card__image-wrap">
        <img className="product-card__image" src={product.image} alt={product.name} />
      </div>
      <h3 className="product-card__name">{product.name}</h3>
      <p className="product-card__price">₹{product.price.toLocaleString('en-IN')}</p>

      <div className="product-card__qty">
        <button className="qty-btn" onClick={decrease} aria-label="Decrease quantity">
          −
        </button>
        <span className="qty-value">{quantity}</span>
        <button className="qty-btn" onClick={increase} aria-label="Increase quantity">
          +
        </button>
      </div>

      <button className="product-card__add-btn" onClick={handleAddToCart}>
        Add to Cart
      </button>
    </article>
  )
}

export default ProductCard
