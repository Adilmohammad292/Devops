function Footer() {
  return (
    <footer className="footer">
      <p>Online Shopping Cart App &middot; Built with React + Vite</p>
      <p className="footer__sub">Assignment 8.1.2 &mdash; Props &amp; State Management Demo</p>
    </footer>
  )
}

export default Footer
