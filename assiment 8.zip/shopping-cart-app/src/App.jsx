import { useState } from 'react'
import Header from './components/Header'
import ProductList from './components/ProductList'
import Cart from './components/Cart'
import Footer from './components/Footer'
import productsData from './data/products'
import './App.css'

function App() {
  // Product catalog lives in state (even though it doesn't change here) so
  // it's easy to extend later -- e.g. loading it from an API.
  const [products] = useState(productsData)

  // The cart is the core piece of shared state. Each entry is a product
  // plus a quantity. App owns this state and passes both the data and the
  // functions that change it down to children via props.
  const [cartItems, setCartItems] = useState([])
  const [toast, setToast] = useState('')

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0)
  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const showToast = (message) => {
    setToast(message)
    setTimeout(() => setToast(''), 2000)
  }

  const handleAddToCart = (product, quantity) => {
    setCartItems((prevItems) => {
      const existing = prevItems.find((item) => item.id === product.id)
      if (existing) {
        return prevItems.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        )
      }
      return [...prevItems, { ...product, quantity }]
    })
    showToast(`${product.name} added to cart!`)
  }

  const handleRemove = (productId) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== productId))
  }

  const handleChangeQty = (productId, newQuantity) => {
    if (newQuantity < 1) {
      handleRemove(productId)
      return
    }
    setCartItems((prevItems) =>
      prevItems.map((item) => (item.id === productId ? { ...item, quantity: newQuantity } : item))
    )
  }

  const handleClearCart = () => {
    setCartItems([])
  }

  return (
    <div className="app">
      <Header appName="Online Shopping" cartCount={cartCount} />

      <main className="app__main">
        <h1 className="app__welcome">Welcome to Online Shopping</h1>

        <div className="app__layout">
          <ProductList products={products} onAddToCart={handleAddToCart} />
          <Cart
            cartItems={cartItems}
            onRemove={handleRemove}
            onChangeQty={handleChangeQty}
            onClearCart={handleClearCart}
            total={total}
          />
        </div>
      </main>

      <Footer />

      {toast && <div className="toast">{toast}</div>}
    </div>
  )
}

export default App
