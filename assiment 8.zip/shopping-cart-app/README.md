# Shopping Cart App (Assignment 8.1.2)

A React + Vite shopping cart demo built with props and `useState`.

## Setup

1. Install [Node.js](https://nodejs.org/) (v18+) and VS Code, if you haven't already.
2. Unzip this project, then open a terminal in the `shopping-cart-app` folder.
3. Install dependencies:
   ```
   npm install
   ```
4. Start the dev server:
   ```
   npm run dev
   ```
5. Open the printed local URL (usually `http://localhost:5173`) in your browser.

## Project structure

```
shopping-cart-app/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx          # renders <App /> into the DOM
    ├── App.jsx           # owns cart + product state, wires props to children
    ├── App.css           # all styling
    ├── index.css         # base reset
    ├── data/
    │   └── products.js   # product catalog (name, price, image)
    └── components/
        ├── Header.jsx      # app name + live cart count
        ├── ProductList.jsx # maps products -> ProductCard
        ├── ProductCard.jsx # single product, qty picker, "Add to Cart"
        ├── Cart.jsx        # cart items, qty +/-, remove, total, clear
        └── Footer.jsx      # static app info
```

## How it satisfies the assignment

- **Props**: `App` passes `products` and `onAddToCart` to `ProductList`,
  which passes each `product` + `onAddToCart` to `ProductCard`. `App` passes
  `cartCount` to `Header`, and `cartItems`/callbacks/`total` to `Cart`.
- **State**: `App` holds `cartItems` in `useState`. Adding, removing,
  changing quantity, and clearing the cart all go through `setCartItems`,
  so every consumer (Header's count, Cart's list, the total) updates
  automatically.
- **Empty state**: Cart shows "Cart is Empty" when `cartItems.length === 0`.
- **Bonus**: quantity +/- controls (on both the product card before adding
  and inside the cart), live total price by quantity, a "Clear Cart"
  button, and a toast message on successful add.
